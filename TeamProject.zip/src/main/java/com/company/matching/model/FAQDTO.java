package com.company.matching.model;

public class FAQDTO {
	private int faqNum;
	private String faqCate;
	private String faqSubject;
	private String faqContent;
	public int getFaqNum() {
		return faqNum;
	}
	public void setFaqNum(int faqNum) {
		this.faqNum = faqNum;
	}
	public String getFaqCate() {
		return faqCate;
	}
	public void setFaqCate(String faqCate) {
		this.faqCate = faqCate;
	}
	public String getFaqSubject() {
		return faqSubject;
	}
	public void setFaqSubject(String faqSubject) {
		this.faqSubject = faqSubject;
	}
	public String getFaqContent() {
		return faqContent;
	}
	public void setFaqContent(String faqContent) {
		this.faqContent = faqContent;
	}
	
}
