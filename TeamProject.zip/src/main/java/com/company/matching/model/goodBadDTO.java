package com.company.matching.model;

public class goodBadDTO {
	private int gbNum;
	private int userNum;
	private int comNum;
	private String gb;
	public int getGbNum() {
		return gbNum;
	}
	public void setGbNum(int gbNum) {
		this.gbNum = gbNum;
	}
	public int getUserNum() {
		return userNum;
	}
	public void setUserNum(int userNum) {
		this.userNum = userNum;
	}
	public int getComNum() {
		return comNum;
	}
	public void setComNum(int comNum) {
		this.comNum = comNum;
	}
	public String getGb() {
		return gb;
	}
	public void setGb(String gb) {
		this.gb = gb;
	}
	
	
}
