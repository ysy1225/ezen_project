package com.company.matching.model;

public class TutorDTO {
	
	private int tutorNum;
	private int userNum;
	private String tutorNickName;
	private String tutorMajor;
	private String tutorContent;
	private String filename_face;
	private int filesize_face;
	private String filename;
	private int filesize;
	private String tutorDate;
	private int tutorLevel;
	
	public int getTutorNum() {
		return tutorNum;
	}
	public void setTutorNum(int tutorNum) {
		this.tutorNum = tutorNum;
	}
	public int getUserNum() {
		return userNum;
	}
	public void setUserNum(int userNum) {
		this.userNum = userNum;
	}
	public String getTutorNickName() {
		return tutorNickName;
	}
	public void setTutorNickName(String tutorNickName) {
		this.tutorNickName = tutorNickName;
	}
	public String getTutorMajor() {
		return tutorMajor;
	}
	public void setTutorMajor(String tutorMajor) {
		this.tutorMajor = tutorMajor;
	}
	public String getTutorContent() {
		return tutorContent;
	}
	public void setTutorContent(String tutorContent) {
		this.tutorContent = tutorContent;
	}
	public String getFilename_face() {
		return filename_face;
	}
	public void setFilename_face(String filename_face) {
		this.filename_face = filename_face;
	}
	public int getFilesize_face() {
		return filesize_face;
	}
	public void setFilesize_face(int filesize_face) {
		this.filesize_face = filesize_face;
	}
	public String getFilename() {
		return filename;
	}
	public void setFilename(String filename) {
		this.filename = filename;
	}
	public int getFilesize() {
		return filesize;
	}
	public void setFilesize(int filesize) {
		this.filesize = filesize;
	}
	public String getTutorDate() {
		return tutorDate;
	}
	public void setTutorDate(String tutorDate) {
		this.tutorDate = tutorDate;
	}
	public int getTutorLevel() {
		return tutorLevel;
	}
	public void setTutorLevel(int tutorLevel) {
		this.tutorLevel = tutorLevel;
	}

}
