package com.company.matching.model;

public class chatRoomDTO {
	private int crNum;
	private int sUserNum;
	private int rUserNum;
	private String sName;
	private String rName;
	public int getCrNum() {
		return crNum;
	}
	public void setCrNum(int crNum) {
		this.crNum = crNum;
	}
	public int getsUserNum() {
		return sUserNum;
	}
	public void setsUserNum(int sUserNum) {
		this.sUserNum = sUserNum;
	}
	public int getrUserNum() {
		return rUserNum;
	}
	public void setrUserNum(int rUserNum) {
		this.rUserNum = rUserNum;
	}
	public String getsName() {
		return sName;
	}
	public void setsName(String sName) {
		this.sName = sName;
	}
	public String getrName() {
		return rName;
	}
	public void setrName(String rName) {
		this.rName = rName;
	}
	
	
}
