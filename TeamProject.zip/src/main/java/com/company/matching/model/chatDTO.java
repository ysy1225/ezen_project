package com.company.matching.model;

import com.google.gson.Gson;

public class chatDTO {
	private int chatNum;
	private int crNum;
	private int sUserNum;
	private int rUserNum;
	private String chatContent;
	public int getChatNum() {
		return chatNum;
	}
	public void setChatNum(int chatNum) {
		this.chatNum = chatNum;
	}
	public int getCrNum() {
		return crNum;
	}
	public void setCrNum(int crNum) {
		this.crNum = crNum;
	}
	public int getsUserNum() {
		return sUserNum;
	}
	public void setsUserNum(int sUserNum) {
		this.sUserNum = sUserNum;
	}
	public int getrUserNum() {
		return rUserNum;
	}
	public void setrUserNum(int rUserNum) {
		this.rUserNum = rUserNum;
	}
	public String getChatContent() {
		return chatContent;
	}
	public void setChatContent(String chatContent) {
		this.chatContent = chatContent;
	}
	public static chatDTO convertMessage(String source) {
		chatDTO message = new chatDTO();
		Gson gson = new Gson();
		message = gson.fromJson(source,  chatDTO.class);
		return message;
	}
	@Override
	public String toString() {
		return "chatDTO [chatNum=" + chatNum + ", crNum=" + crNum + ", sUserNum =" + sUserNum
				+ ", rUserNum =" + rUserNum + ", chatContent=" + chatContent + "]";
	}
	
}
