package com.company.matching.service;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.company.matching.model.UsersDTO;
import com.company.matching.model.chatDTO;
import com.company.matching.model.chatRoomDTO;

@Service
public class ChatMapper {
	@Autowired
	private SqlSession sqlSession;
	
	public int insertChat(chatDTO dto){
		return sqlSession.insert("insertChat",dto);
	}
	public String name(int userNum){
		return sqlSession.selectOne("name",userNum);
	}
	public chatRoomDTO isRoom(chatRoomDTO dto) throws Exception {
		return sqlSession.selectOne("isRoom",dto);
	}
	public int createRoom(chatRoomDTO dto){
		return sqlSession.insert("createRoom",dto);
	}
	public List<chatRoomDTO> getChatList(int sUserNum){
		return sqlSession.selectList("getChatList", sUserNum);
	}
	public List<chatDTO> getCtList(int crNum){
		return sqlSession.selectList("getCtList",crNum);
	}
	public UsersDTO getU(int userNum){
		return sqlSession.selectOne("getU",userNum);
	}
	public chatRoomDTO getRoom(int crNum){
		return sqlSession.selectOne("getRoom",crNum);
	}
	public int getRoomId(chatRoomDTO dto){
		return sqlSession.selectOne("getRoomId",dto);
	}
	public List<chatDTO> searchChat(int sUserNum,int rUserNum){
		java.util.Map<String,Object> map = new java.util.Hashtable<String,Object>();
		map.put("sUserNum", sUserNum);
		map.put("rUserNum", rUserNum);
		return sqlSession.selectList("searchChat",map);
	}
	public int getCr(int sUserNum,int rUserNum){
		java.util.Map<String,Object> map = new java.util.Hashtable<String,Object>();
		map.put("sUserNum", sUserNum);
		map.put("rUserNum", rUserNum);
		return sqlSession.selectOne("getCr",map);
	}
}
