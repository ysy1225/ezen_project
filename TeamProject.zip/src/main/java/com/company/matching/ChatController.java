package com.company.matching;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.company.matching.model.UsersDTO;
import com.company.matching.model.chatDTO;
import com.company.matching.model.chatRoomDTO;
import com.company.matching.service.ChatMapper;
import com.company.matching.service.UsersMapper;


/*
이	   름 : ChatController
개  발   자 : 이여진
설	   명 : 채팅 컨트롤러
*/

@Controller
public class ChatController {
	
	@Autowired
	private ChatMapper chatMapper;
	
	@Autowired
	private UsersMapper usersMapper;
	
	
	List<chatRoomDTO> roomList = new ArrayList<chatRoomDTO>();
	
	@RequestMapping("/room")
	public ModelAndView room(HttpSession session, HttpServletRequest req) throws Exception {
		ModelAndView mv = new ModelAndView();

		int userNum=(Integer)session.getAttribute("getUserNum");
		String userName=(String)session.getAttribute("getN");
		int sUserNum=userNum;
		String sName=userName;
		
		String rUserNum = req.getParameter("rUserNum");
		String rName = chatMapper.name(Integer.parseInt(rUserNum));
		
		chatRoomDTO room  = new chatRoomDTO();
	    room.setrUserNum(Integer.parseInt(rUserNum));
	    room.setsUserNum(sUserNum);
	    room.setsName(sName);
	    room.setrName(rName);
	    room.setCrNum(chatMapper.getCr(sUserNum, Integer.parseInt(rUserNum)));
	    
	    roomList.clear();	    
	    if(chatMapper.isRoom(room) == null){
	    	chatMapper.createRoom(room);
	    	roomList.addAll(chatMapper.getChatList(sUserNum));
	    }else{
	    	roomList.addAll(chatMapper.getChatList(sUserNum));
	    }
	   
	    List<chatDTO> ctList=chatMapper.getCtList(chatMapper.getRoomId(room));
	    req.setAttribute("ctList",ctList);
	    req.setAttribute("room", room);
	    req.setAttribute("roomList", roomList);
	    req.setAttribute("crNum", room.getCrNum());
	    req.setAttribute("rName", room.getrName());
		req.setAttribute("sName", room.getsName());
		req.setAttribute("sUserNum", room.getsUserNum());
		req.setAttribute("rUserNum", room.getrUserNum());
	    mv.setViewName("lecture/chatView");
	    return mv;
	/*	Comm_MemberDTO login = (Comm_MemberDTO) session.getAttribute("comm_login");
		int msgSender = login.getComm_memberNum();
		String Sname = login.getComm_nickname();

		
		String msgReceiver = req.getParameter("comm_memberNum");
		String Rname = req.getParameter("comm_nickname");
		
		ChatRoomDTO croom  = new ChatRoomDTO();
	    croom.setMsgReceiver(Integer.parseInt(msgReceiver));
	    croom.setMsgSender(msgSender);
	    croom.setSname(Sname);
	    croom.setRname(Rname);
	    String RProfile = chatMapper.getProfile(Integer.parseInt(msgReceiver));
	    
	    roomList.clear();
		if(chatMapper.isRoom(croom) == null ) {
			chatMapper.createRoom(croom);
			roomList.addAll(chatMapper.getChatList(msgSender));
		}else{
			if(!Sname.equals(chatMapper.isRoom(croom).getSname())){
				chatMapper.updateSname(Sname, msgSender);
				chatMapper.updateRname(Sname, msgSender);
				System.out.println("닉네임 변경 완료");
			}
			roomList.addAll(chatMapper.getChatList(msgSender));

		}

		List<ChatMsgDTO> msgList = chatMapper.getMessageList(chatMapper.getRoomId(croom));
		req.setAttribute("msgList",msgList);
		req.setAttribute("chatroom_id",chatMapper.getRoomId(croom));
		req.setAttribute("msgSender",croom.getMsgSender());
		req.setAttribute("msgReceiver", croom.getMsgReceiver());
		
		req.setAttribute("Sname",croom.getSname());
		req.setAttribute("Rname",croom.getRname());
		req.setAttribute("RProfile",RProfile);
		
		session.setAttribute("croom",croom);
		session.setAttribute("roomList",roomList);
		
		mv.setViewName("comm/chatView");
		return mv;*/
	}
	
	@RequestMapping("/chat")
	public ModelAndView chat() {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("comm/chatView");
		return mv;
	}
	
	@RequestMapping("/roomList")
	public ModelAndView roomList(HttpSession session, HttpServletRequest req) throws Exception {
		ModelAndView mv = new ModelAndView();
		int userNum=(Integer)session.getAttribute("getUserNum");
		int sUserNum=userNum;
		UsersDTO user=chatMapper.getU(sUserNum);
		String sName=user.getUserName();
		
		roomList.clear();
		roomList.addAll(chatMapper.getChatList(sUserNum));
		req.setAttribute("roomList", roomList);
		session.setAttribute("sUserNum", sUserNum);
		mv.setViewName("lecture/chatRoom");
		return mv;
		/*ModelAndView mv = new ModelAndView();
		Comm_MemberDTO login = (Comm_MemberDTO) session.getAttribute("comm_login");
		int msgSender = login.getComm_memberNum();
		Comm_MemberDTO dto = memberMapper.comm_getMember(msgSender);
		String Sname = dto.getComm_nickname();
		chatMapper.updateSname(Sname, msgSender);
		chatMapper.updateRname(Sname, msgSender);
		
		
		roomList.clear();
		roomList.addAll(chatMapper.getChatList(msgSender));
		
		req.setAttribute("roomList",roomList);
		session.setAttribute("msgSender",msgSender);
		mv.setViewName("comm/chatRoom");
		
		return mv;*/
	}
	
	@RequestMapping("/moveChating")
	public ModelAndView chating(HttpServletRequest req, HttpSession session) throws Exception {
		ModelAndView mv = new ModelAndView();
		
		//int crNum = chatMapper.getCr((Integer)session.getAttribute("getUserNum"), Integer.parseInt(req.getParameter("asd")));
		int crNum = Integer.parseInt(req.getParameter("crNum"));
		int sUserNum=(Integer)session.getAttribute("getUserNum");
		List<chatDTO> ctList=chatMapper.getCtList(crNum);
		List<chatRoomDTO> new_list=roomList.stream().filter(o->o.getCrNum()==crNum).collect(Collectors.toList());
		chatRoomDTO room = chatMapper.getRoom(crNum);
		String sName=chatMapper.name(sUserNum);
		String rName;
		int rUserNum;
		if(sUserNum == room.getsUserNum()){
			rUserNum = room.getrUserNum();
			rName = chatMapper.name(rUserNum);
		}else{
			rUserNum = room.getrUserNum();
			rName = chatMapper.name(rUserNum);
		}
	    
	    
		if(new_list != null && new_list.size() > 0) {
			req.setAttribute("room", room);
			req.setAttribute("ctList", ctList);
			req.setAttribute("crNum", crNum);
			req.setAttribute("sUserNum", sUserNum);
			req.setAttribute("rUserNum", rUserNum);
			req.setAttribute("rName", rName);
			req.setAttribute("sName", sName);
			mv.setViewName("lecture/chatView");
		}else{
			mv.setViewName("lecture/chatRoom");
		}
		return mv;
		
		
		
		/*ModelAndView mv = new ModelAndView();
		int chatroom_id = Integer.parseInt(req.getParameter("chatroom_id"));
		int msgSender = (int)session.getAttribute("msgSender");
		List<ChatMsgDTO> msgList = chatMapper.getMessageList(chatroom_id);
		List<ChatRoomDTO> new_list = roomList.stream().filter(o->o.getChatroom_id()==chatroom_id).collect(Collectors.toList());
		ChatRoomDTO croom = chatMapper.getRoomList(chatroom_id);
		
		String RProfile;
		int msgReceiver = 0;
		if(msgSender == croom.getMsgSender()){
			msgReceiver = croom.getMsgReceiver();
			RProfile = chatMapper.getProfile(msgReceiver);
		}else{
			msgReceiver = croom.getMsgSender();
			RProfile = chatMapper.getProfile(msgReceiver);
		}
		
		if(new_list != null && new_list.size() > 0) {
			
			req.setAttribute("msgList",msgList);
			req.setAttribute("chatroom_id",chatroom_id);
			req.setAttribute("msgSender",msgSender);
			req.setAttribute("msgReceiver", msgReceiver);
			req.setAttribute("RProfile",RProfile);
			req.setAttribute("Rname",croom.getRname());
			req.setAttribute("Sname",croom.getSname());
			mv.setViewName("comm/chatView");
		}else {
			mv.setViewName("comm/chatRoom");
		}
		return mv;*/
	}

}